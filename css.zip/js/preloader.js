$(document).ready(function() {
    $("#site-preloader").hide("slow");
    $(document.body).removeClass("overflow-hidden");
});
