$(document).ready(function() {
  lightbox.option({
    alwaysShowNavOnTouchDevices: true,
    disableScrolling: true
  });
});
